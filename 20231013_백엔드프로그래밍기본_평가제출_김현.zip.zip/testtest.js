let arr = [];
for(i=0; i<16; i++) {
  arr[arr.length] = Math.floor(Math.random() * 40-1)+1
}

console.log(arr)